$(document).ready(function(){
           $(window).on('scroll', function () {
        if ($(this).scrollTop() > 220) { // Set position from top to add class
            $('.navbar').addClass('header-appear');
        }
        else {
            $('.navbar').removeClass('header-appear');
        }
       }); 
    });
$(document).ready(function(){  
$(function(){
new WOW().init(); 

});
 });
